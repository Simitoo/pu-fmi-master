package com.project01_rent_a_car_api.P01RentACar_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P01RentACarApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
