package com.project01_rent_a_car_api.P01RentACar_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P01RentACarApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(P01RentACarApiApplication.class, args);
	}

}
