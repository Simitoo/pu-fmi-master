package com.project01_rent_a_car_api.P01RentACar_api.service;

import com.project01_rent_a_car_api.P01RentACar_api.constants.ExceptionMessages;
import com.project01_rent_a_car_api.P01RentACar_api.entities.Offer;
import com.project01_rent_a_car_api.P01RentACar_api.repositories.OfferRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class OfferService {

    @Autowired
    private OfferRepository offerRepository;
    private ClientService clientService;
    private CarService carService;

    public OfferService(OfferRepository offerRepository, ClientService clientService, CarService carService){
        this.offerRepository = offerRepository;
        this.clientService = clientService;
        this.carService = carService;
    }

    public String createOffer(int clientId, int carId, int rentDays){

        if(!isValidCarIdAndClientId(carId,clientId)){
            return "Failed to create offer due to invalid client or car ID";
        }

        Offer offerToAdd = new Offer();
        boolean clientHasAccidents = clientService.hasAccidents(clientId);
        double carPrice = carService.getCarById(carId).get().getPricePerDay();

        offerToAdd.setClientId(clientId);
        offerToAdd.setCarId(carId);
        offerToAdd.setRentDays(rentDays);
        offerToAdd.setFinalPrice(calculatePrice(rentDays, clientHasAccidents, carPrice));


        boolean successInsert = offerRepository.insertRecord(offerToAdd);

        return printOffer(offerToAdd,successInsert);
    }

    public List<Offer> getAllOffers(){
        return offerRepository.getAll();
    }

    public Optional<Offer> getOfferById (int id){
        if(offerRepository.getById(id).isEmpty()){
            throw new RuntimeException(ExceptionMessages.RECORD_NOT_FOUND);
        }

        return offerRepository.getById(id);
    }

    public boolean updateOffer(int id, Offer offer){
        return offerRepository.updateRecord(id,offer);
    }

    public boolean deleteOffer(int id){
        return offerRepository.deleteRecord(id);
    }

    public void acceptOffer(Offer offer){
        this.offerRepository.acceptOfferById(offer.getId());
    }

    private double calculatePrice(int rentDays, boolean hasAccidents, double pricePerDay){

        double finalPrice = pricePerDay * rentDays;

        if(isOnWeekend(rentDays)){

            finalPrice *= 1.1;
        }

        if(hasAccidents){
            finalPrice += 200;
        }

        return finalPrice;
    }

    private boolean isOnWeekend(int rentDays){
        LocalDate today = LocalDate.now();
        LocalDate rentDay;

        for (int i = 0; i < rentDays; i++){
            rentDay = today.plusDays(i);

            if(rentDay.getDayOfWeek() == DayOfWeek.SATURDAY || rentDay.getDayOfWeek() == DayOfWeek.SUNDAY){
                return true;
            }
        }

        return false;
    }

    private boolean isValidCarIdAndClientId(int carId, int clientId){
        if(clientService.getClientById(clientId).isEmpty()){
            throw new RuntimeException(ExceptionMessages.NON_EXISTED_CLIENT + clientId);
        }

        if(carService.getCarById(carId).isEmpty()){
            throw new RuntimeException(ExceptionMessages.NON_EXISTED_CAR + carId);
        }

        return true;
    }

    private String printOffer(Offer offer, boolean isInsertSuccessful){

        if(isInsertSuccessful){
            return String.format("Offer ID: %d\nClient: %d\nCar: %d\nTotal Price: %s",
                    offer.getId(),offer.getClientId(),offer.getCarId(),offer.getFinalPrice());
        }

        return "Failed to create the Offer!";
    }
}
